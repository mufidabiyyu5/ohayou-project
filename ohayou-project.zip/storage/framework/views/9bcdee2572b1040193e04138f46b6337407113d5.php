<nav class="navbar navbar-expand-lg py-2" id="mynav">
    <div class="container container-fluid">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(url('frontend/assets/images/Logo.png')); ?>" alt="Logo Ohayou" height="64"
                width="64"></a>
        <button class="navbar-toggler collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#navbar"
            aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-collapse collapse" id="navbar">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('products')); ?>">Produk</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('order')); ?>">Cara Order</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('about')); ?>">Tentang Kami</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('portfolio')); ?>">Portfolio</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('testimoni')); ?>">Testimoni</a>
                </li>

            </ul>
            
        </div>
    </div>
</nav><?php /**PATH C:\Users\Acer\Documents\Skripsi\ohayou-project\resources\views/includes/navbar.blade.php ENDPATH**/ ?>