

<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Tambah Testimoni</h1>
                    </div>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <!-- Content Row -->
                    <div class="card shadow">
                        <div class="card-body">
                            <form action="<?php echo e(route('testimonial.store')); ?>" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="customer">Nama Customer</label>
                                    <input type="text" class="form-control" name="customer" placeholder="Contoh: Bambang" value="<?php echo e(old('customer')); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="about_customer">Bio Customer</label>
                                    <input type="text" class="form-control" name="about_customer" placeholder="Contoh: Pembeli di Shopee" value="<?php echo e(old('about_customer')); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="image">Foto Customer Max: 2MB</label>
                                    <input type="file" name="image" class="form-control" placeholder="Max: 2MB">
                                </div>
                                <div class="form-group">
                                    <label for="testimoni">Testimoni</label>
                                    <textarea name="testimoni" rows="10" class="d-block w-100 form-control"><?php echo e(old('testimoni')); ?></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block">
                                    Simpan
                                </button>
                            </form>
                        </div>
                    </div>


                </div>
                <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Acer\Documents\Skripsi\ohayou-project\resources\views/pages/admin/testimonial/create.blade.php ENDPATH**/ ?>