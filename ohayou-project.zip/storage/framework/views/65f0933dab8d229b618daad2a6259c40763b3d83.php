<link rel="stylesheet" href="<?php echo e(Url('frontend/bootstrap/css/bootstrap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(Url('frontend/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(Url('frontend/css/style.css')); ?>">
<link href="<?php echo e(url('https://unpkg.com/aos@2.3.1/dist/aos.css')); ?>" rel="stylesheet"><?php /**PATH C:\Users\Acer\Documents\Skripsi\ohayou-project\resources\views/includes/style.blade.php ENDPATH**/ ?>