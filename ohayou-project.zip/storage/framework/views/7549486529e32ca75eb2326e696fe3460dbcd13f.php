

<?php $__env->startSection('title'); ?>
    <?php echo e($items->title); ?> - Ohayou.Co
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <nav class="container container-fluid" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('products')); ?>">Produk</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('products')); ?>"><?php echo e($items->categories->name); ?></a></li>
                <li class="breadcrumb-item active"><?php echo e($items->title); ?></li>
            </ol>
        </nav>
        <section class="container container-fluid detail-title">
            <div class="row align-items-start">
                <div class="col-lg-4">
                    <div class="card-details">
                        <div class="xzoom-container">
                            <img src="<?php echo e(Storage::url($items->galleries->first()->image)); ?>" class="xzoom img-fluid" id="xzoom-default" height="350"
                                xoriginal="<?php echo e(Storage::url($items->galleries->first()->image)); ?>">
                        </div>
                        <div class="xzoom-thumbs">
                            <?php $__currentLoopData = $items->galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(Storage::url($item->image)); ?>">
                                    <img src="<?php echo e(Storage::url($item->image)); ?>" class="xzoom-gallery" width="64" height="60"
                                        xpreview="<?php echo e(Storage::url($item->image)); ?>">
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <h2><?php echo e($items->title); ?></h2>
                    <h4>Mulai dari</h4>
                    <h1>Rp <?php echo e(number_format($items->price)); ?> / pcs</h1>
                    <?php if($items->isbestselling): ?>
                        <div class="d-flex align-items-center badge-product">
                            <img src="<?php echo e(url('frontend/assets/icon/thumbs.svg')); ?>" alt="thumbs">
                            <span>Produk paling laku</span>
                        </div>
                    <?php endif; ?>
                    <?php if($items->sold >= 500): ?>
                        <p>Terjual 500+ pcs</p>
                    <?php else: ?>
                        <p>Terjual <?php echo e($items->sold); ?> pcs</p>
                    <?php endif; ?>
                    <p>Bahan: <?php echo e($items->material); ?></p>
                </div>
                <div class="col-lg-3">
                    <div class="card-contact d-block">
                        <p>Kamu dapat melakukan konsultasi terlebih dahulu atau pesan melalui Whatsapp kami</p>
                        <a href="http://wa.me/6289525958301?text=Halo, Saya ingin memesan <?php echo e($items->title); ?>" target="_blank" class="btn btn-primary d-block">
                            <img src="<?php echo e(url('frontend/assets/icon/ri-whatsapp-line.svg')); ?>" alt="Pesan"> Pesan
                        </a>
                        <a href="http://wa.me/6289525958301?text=Halo, Saya ingin menanyakan terkait produk <?php echo e($items->title); ?>" target="_blank" class="btn btn-outline-primary d-block">
                            <img src="<?php echo e(url('frontend/assets/icon/message.svg')); ?>" alt="konsultasi"> Konsultasi
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <section class="container container-fluid description">
            <h3>Deskripsi Produksi</h3>
            <p><?php echo e($items->description); ?></p>
        </section>
        <section class="container container-fluid price-list">
            <h3>Daftar Harga</h3>
            <div class="row align-items-center">
                <?php $__currentLoopData = $items->price_list->sortBy('price'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($key == 0): ?>
                        <div class="col-lg-3">
                            <div class="card-main-price">
                                <h4><?php echo e($item->title); ?></h4>
                                <h3>Rp <?php echo e(number_format($item->price)); ?> / pcs</h3>
                                <hr>
                                <div class="d-block featured">
                                    <?php $__currentLoopData = $item->description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <img src="<?php echo e(url('frontend/assets/icon/check-white.svg')); ?>" alt="check">
                                            <span><?php echo e($desc['value']); ?></span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="col-lg-3">
                            <div class="card-price">
                                <h4><?php echo e($item->title); ?></h4>
                                <h3>Rp <?php echo e(number_format($item->price)); ?> / pcs</h3>
                                <hr>
                                <div class="d-block featured">
                                    <?php $__currentLoopData = $item->description; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <img src="<?php echo e(url('frontend/assets/icon/check-yellow.svg')); ?>" alt="check">
                                            <span><?php echo e($desc['value']); ?></span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
        <section class="contact">
            <div class="container container-fluid d-block">
                <h2 class="text-center">
                    Yuk! Tunggu Apalagi? <br />
                    Langsung Pesan Ke Ohayou.co, Kami Selalu Siap Membantu
                </h2>
                <div class="text-center">
                    <a href="http://wa.me/6289525958301" target="_blank" class="btn btn-white">
                        <img src="<?php echo e(url('frontend/assets/icon/ri-whatsapp-line-black.svg')); ?>" alt="Whatsapp">
                        Hubungi Whatsapp Kami
                    </a>
                    <br/>
                    <a href="https://www.instagram.com/ohayou_co/" target="_blank" class="btn btn-outline-white">
                        <img src="<?php echo e(url('frontend/assets/icon/ri-instagram-line.svg')); ?>" alt="Instagram">
                        Cek Instagram Kami
                    </a>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Acer\Documents\Skripsi\ohayou-project\resources\views/pages/detail.blade.php ENDPATH**/ ?>