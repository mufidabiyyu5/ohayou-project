<?php echo e($slot); ?>

<?php /**PATH C:\Users\Acer\Documents\Skripsi\ohayou-project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>