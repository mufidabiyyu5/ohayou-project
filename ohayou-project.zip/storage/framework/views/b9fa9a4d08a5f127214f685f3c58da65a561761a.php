

<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Tambah Paket Harga</h1>
                    </div>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <!-- Content Row -->
                    <div class="card shadow">
                        <div class="card-body">
                            <form action="<?php echo e(route('price_list.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="products_id">Produk</label>
                                    <select name="products_id" required class="form-control">
                                        <option value="">Pilih Produk</option>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($product->id); ?>">
                                                <?php echo e($product->title); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="title">Nama Paket</label>
                                    <input type="text" class="form-control" name="title" placeholder="Contoh: Paket A" value="<?php echo e(old('title')); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="price">Harga</label>
                                    <input type="number" class="form-control" name="price" placeholder="Masukan harga..." value="<?php echo e(old('price')); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="material">Keuntungan atau Syarat Paket Ini</label>
                                    <?php for($i = 0; $i < 4; $i++): ?>
                                        <input type="hidden" class="form-control" name="description[<?php echo e($i); ?>][key]" value="<?php echo e($i); ?>">
                                        <input type="text" class="form-control my-2" name="description[<?php echo e($i); ?>][value]" placeholder="Contoh: Sablon rubber 4 warna" value="<?php echo e(old('description['.$i.'][value]')); ?>">
                                    <?php endfor; ?>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block">
                                    Simpan
                                </button>
                            </form>
                        </div>
                    </div>


                </div>
                <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Acer\Documents\Skripsi\ohayou-project\resources\views/pages/admin/price_list/create.blade.php ENDPATH**/ ?>