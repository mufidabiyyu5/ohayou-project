<!doctype html>
<html lang="id-ID">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <?php echo $__env->yieldPushContent('prepend-style'); ?>
    <?php echo $__env->make('includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('addon-style'); ?>
    
    <title><?php echo $__env->yieldContent('title'); ?></title>
    
    <link rel="shortcut icon" href="<?php echo e(url('frontend/assets/images/Logo.png')); ?>">
</head>

<body class="landingpage">
    <!-- Navbar -->
    <?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Floating button -->
    <a href="#" class="float">
        <img src="frontend/assets/icon/ri-whatsapp-notif.svg" alt="" class="my-float" width="24" height="24">
        chat with us
    </a>

    <?php echo $__env->yieldPushContent('prepend-script'); ?>
    <?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('addon-script'); ?>

</body>

</html><?php /**PATH C:\Users\Acer\Documents\Skripsi\ohayou-project\resources\views/layouts/app.blade.php ENDPATH**/ ?>