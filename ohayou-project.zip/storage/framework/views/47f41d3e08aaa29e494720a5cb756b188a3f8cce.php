<!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard')); ?>">
                <div class="sidebar-brand-text mx-3">
                    Ohayou.co Admin
                </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">
            
            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>
            
            <!-- Nav Item - Paket Travel -->
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('category.index')); ?>">
                    <i class="fas fa-fw fa-hotel"></i>
                    <span>Kategori Produk</span></a>
            </li>

            <!-- Nav Item - Galeri Travel -->
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('product.index')); ?>">
                    <i class="fas fa-fw fa-tags"></i>
                    <span>Produk</span></a>
            </li>

            <!-- Nav Item - Transaksi -->
            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('gallery.index')); ?>">
                    <i class="fas fa-fw fa-images"></i>
                    <span>Galeri Produk</span></a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('price_list.index')); ?>">
                    <i class="fas fa-fw fa-dollar-sign"></i>
                    <span>Daftar Paket Harga</span></a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('testimonial.index')); ?>">
                    <i class="fas fa-fw fa-star"></i>
                    <span>Testimoni</span></a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('portfolio.index')); ?>">
                    <i class="fas fa-fw fa-image"></i>
                    <span>Portfolio</span></a>
            </li>

            <li class="nav-item ">
                <a class="nav-link" href="<?php echo e(route('client.index')); ?>">
                    <i class="fas fa-fw fa-briefcase"></i>
                    <span>Klien</span></a>
            </li>

            <?php if(Auth::user()->role == "SUPERADMIN"): ?>
                <li class="nav-item ">
                    <a class="nav-link" href="<?php echo e(route('list_admin.index')); ?>">
                        <i class="fas fa-fw fa-users"></i>
                        <span>List Admin</span></a>
                </li>
            <?php endif; ?>

            <hr class="sidebar-divider">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

            
        </ul>
        <!-- End of Sidebar --><?php /**PATH C:\Users\Acer\Documents\Skripsi\ohayou-project\resources\views/includes/admin/sidebar.blade.php ENDPATH**/ ?>