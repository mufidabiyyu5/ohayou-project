<link rel="stylesheet" href="{{Url('frontend/bootstrap/css/bootstrap.css')}}">
<link rel="stylesheet" href="{{Url('frontend/bootstrap/css/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{Url('frontend/css/style.css')}}">
<link href="{{url('https://unpkg.com/aos@2.3.1/dist/aos.css')}}" rel="stylesheet">