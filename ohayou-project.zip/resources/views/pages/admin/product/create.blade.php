@extends('layouts.admin')

@section('content')
    <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Tambah Produk</h1>
                    </div>

                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{$error}}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    <!-- Content Row -->
                    <div class="card shadow">
                        <div class="card-body">
                            <form action="{{route('product.store')}}" method="POST">
                                @csrf
                                <div class="form-group">
                                    <label for="category_id">Kategori</label>
                                    <select name="category_id" required class="form-control">
                                        <option value="">Pilih Kategori</option>
                                        @foreach ($categories as $category)
                                            <option value="{{$category->id}}">
                                                {{$category->name}}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="title">Nama Produk</label>
                                    <input type="text" class="form-control" name="title" placeholder="Masukan nama produk" value="{{old('title')}}">
                                </div>
                                <div class="form-group">
                                    <label for="price">Harga mulai dari ...</label>
                                    <input type="number" class="form-control" name="price" placeholder="Masukan harga mulai dari..." value="{{old('price')}}">
                                </div>
                                <div class="form-group">
                                    <label for="description">Deskripsi Produk</label>
                                    <textarea name="description" rows="10" class="d-block w-100 form-control">{{old('description')}}</textarea>
                                </div>
                                <div class="form-group">
                                    <label for="sold">Telah terjual</label>
                                    <input type="number" class="form-control" name="sold" placeholder="Terjual berapa pcs?" value="{{old('sold')}}">
                                </div>
                                <div class="form-group">
                                    <label for="material">Bahan</label>
                                    <input type="text" class="form-control" name="material" placeholder="Contoh: Cotton Combed 30s" value="{{old('material')}}">
                                </div>
                                <div class="form-group">
                                    <label for="isbestselling">Apakah produk ini salah satu yang paling laris?</label>
                                    <select name="isbestselling" required class="form-control">
                                        <option value="0">Pilih Opsi</option>
                                        <option value="1">Ya</option>
                                        <option value="0">Tidak</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block">
                                    Simpan
                                </button>
                            </form>
                        </div>
                    </div>


                </div>
                <!-- /.container-fluid -->
@endsection